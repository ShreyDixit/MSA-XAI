Four figures: vector PDF, editable-text SVG, 600-dpi PNG. Captions and explanations are in ILLUSTRATED_REPORT.pdf. Colors follow MLP/visual_config.py.
