Six DCGAN figures: vector PDF, editable-text SVG, and 600-dpi PNG.
Colors, sizes, and axes follow the repository's MLP/LLM visual configuration.
Figure layers 1-5 correspond to CSV/model layers 0-4.
The qualitative plate uses notebook image 30; its JSON records selections and display scales.
See ILLUSTRATED_REPORT.pdf alongside this archive for explanations and captions.
